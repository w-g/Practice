﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Org.Library.Extension
{
    public class Class1
    {
        public Class1()
        {
        }
    }
}
